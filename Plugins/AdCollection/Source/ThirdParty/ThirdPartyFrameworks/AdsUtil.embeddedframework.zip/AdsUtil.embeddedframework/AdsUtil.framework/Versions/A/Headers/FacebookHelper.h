//
//  FacebookHelper.h
//  AdsUtil
//
//  Created by Xufei Wu on 2018/9/23.
//  Copyright © 2018年 Xufei Wu. All rights reserved.
//

#ifndef FacebookHelper_h
#define FacebookHelper_h

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface FacebookHelper : NSObject

+ (FacebookHelper*) GetDelegate;
- (void) InitSDK:(UIViewController*) viewController BannerUnit:(NSString*)BannerUnit InterstitalUnit:(NSString*)InterstitalUnit RewardedUnit:(NSString*)RewardedUnit callback:(void(*)()) callback rewardClose:(void(*)()) rewardClose interstitialShow:(void(*)()) interstitialShow  interstitialClick:(void(*)()) interstitialClick interstitialClose:(void(*)()) interstitialClose;
-(void) ShowBanner:(UIViewController*) viewController isBottom:(BOOL)isBottom;
-(void) HideBanner;
-(void) IsBannerReady:(NSMutableDictionary*)result;
-(void) ShowInterstitialAds:(UIViewController*) viewController;
-(void) IsInterstitalReady:(NSMutableDictionary*)result;
-(void) Play:(UIViewController*) viewController;
-(void) IsPlayable:(NSMutableDictionary*)result;

@end


#endif /* FacebookHelper_h */
