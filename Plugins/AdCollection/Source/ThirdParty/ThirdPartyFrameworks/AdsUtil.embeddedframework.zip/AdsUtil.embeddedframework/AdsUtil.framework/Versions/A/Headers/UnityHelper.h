//
//  UnityHelper.h
//  AdsUtil
//
//  Created by Xufei Wu on 2017/6/28.
//  Copyright © 2017年 Xufei Wu. All rights reserved.
//

#ifndef UnityHelper_h
#define UnityHelper_h

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UnityHelper : NSObject

+ (UnityHelper*) GetDelegate;
- (void) InitSDK:(NSString*) AppID placement:(NSString*) placement callback:(void(*)()) callback rewardClose:(void(*)()) rewardClose;
-(void) Play:(UIViewController*) viewController;
-(void) IsPlayable:(NSMutableDictionary*)result;
-(void) SetPlacement:(NSString*) placement;

@end

#endif /* UnityHelper_h */
